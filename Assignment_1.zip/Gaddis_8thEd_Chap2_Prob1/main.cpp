/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 4, 2016, 12:00 PM
 * Purpose: Problem 1
 */

#include <iostream>

using namespace std;
int main() 
//this program will store the integers 50 and 100, and their total when added together.
{
int num1, num2, total;
num1 = 50; //storing 50 as a variable
num2 = 100; //storing 100 as a variable
total = num1 + num2; //storing the total as a variable
    return 0;
}

