/* 
 * File:   main.cpp
 * Author: Brandon
 * Created on March 4, 2016, 12:08 PM
 * Purpose: problem 2
 */

#include <iostream>
#include <iomanip>

using namespace std;
int main() 
//this program will compute the total sales of the East Coast division of a company
{
    float ts, ecs, sp; // total sales, east coast sales, sales percentage
    ts = 8600000;
    sp = 0.58;
    ecs = ts * sp;
    cout << "The East Coast division of the company is responsible for " << fixed << showpoint << setprecision (2) << ecs << " dollars in sales.";
    return 0;
}

