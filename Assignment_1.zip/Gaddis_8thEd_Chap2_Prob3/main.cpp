/* 
 * File:   main.cpp
 * Author: Brandon
 * Created on March 4, 2016, 12:23 PM
 * Purpose: problem 3
 */

#include <iostream>

using namespace std;
int main() 
//this program will calculate total sales tax 
{
    int cost;
    float tax, txtotal;
    cost = 95;
    tax = 0.06;
    txtotal = cost * tax;
    cout << "The sales tax on a $95 purchase with 6% tax is $" << txtotal << ".";
    return 0;
}

