/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 7, 2016, 9:39 AM
 * Purpose: probelm 19
 */

#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main() 
//Calculating monthly payment for a loan
{
    float loanamt; //loan amount
    float intst; // interest rate
    int nop; //number of payments
    float mp; //monthly payment
    float temp; //this is the 1+r to the n part of the equation
    cout << "What is the loan amount?" << endl;
    cin >> loanamt;
    cout << "What is the yearly interest rate? Enter as a decimal." << endl;
    cin >> intst;
    cout << "How many monthly payments do you need to make?" << endl;
    cin >> nop;
    intst = intst/12; //turn the yearly interest into monthly interest
    temp = pow(1+intst,nop); //placeholder to simplify the equation
    mp = ((intst * temp) / (temp - 1)) * loanamt ;
    intst = intst * 12; //turn monthly interest back into yearly interest
    cout << "With a yearly interest rate of " << intst << "," << endl; //tell them the inputs
    cout << "an initial loan amount of $" << loanamt << " dollars," << endl;
    cout << "and making " << nop << " monthly payments," << endl;
    cout << "your monthly payment will be $" << fixed << showpoint << setprecision(2) << mp << " dollars per month." << endl;
    return 0;
}

