/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 9, 2016, 8:06 AM
 * Purpose: problem 2, Babylonian square root approximation
 */
//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
//Function Prototypes
//Execution begins here
int main() 
{
    //Declare Variables
    float n, r, guess;
    cout << "What is the integer you wish to find the square root of?" << endl;
    cin >> n;
    //Calculate the first approximation
    guess = n/2;
    r = n/guess;
    guess = (guess + r)/2;
    //output the first approximation
    cout << "The first approximation = square root (" << n << ") = r("
            << r << "),guess("<<guess<<")" << endl;
    //Second approximation
    r = n/guess;
    guess = (guess + r)/2;
    //output the second approximation
    cout << "The second approximation = square root (" << n << ") = r("
            << r << "),guess("<<guess<<")" << endl;
    //Third approximation
    r = n/guess;
    guess = (guess + r)/2;
    //output the third approximation
    cout << "The third approximation = square root (" << n << ") = r("
            << r << "),guess("<<guess<<")" << endl;
    //Fourth approximation
        r = n/guess;
    guess = (guess + r)/2;
    //output the fourth approximation
    cout << "The fourth approximation = square root (" << n << ") = r("
            << r << "),guess("<<guess<<")" << endl;
    //The fifth approximation
    r = n/guess;
    guess = (guess + r)/2;
    //output the fifth approximation
    cout << "The fifth approximation = square root (" << n << ") = r("
            << r << "),guess("<<guess<<")" << endl;
    r = n/guess;
    guess = (guess + r)/2;
    //output the sixth approximation
    cout << "The sixth approximation = square root (" << n << ") = r("
            << r << "),guess("<<guess<<")" << endl;
    //Exit Stage Left
    return 0;
}

