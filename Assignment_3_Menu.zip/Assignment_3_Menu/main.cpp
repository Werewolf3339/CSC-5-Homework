/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 30, 2016, 9:31 AM
 * Purpose: creating a menu to view problems 1-10
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() 

//execution begins here

{
    int key; // menu selection
    
    cout << "Enter a number, 1-10, in order to view that problem." << endl;
    cout << "Entering anything other than 1-10 will cause the menu to exit." << endl;
    cin >> key;

    switch (key) {
        case (1):{ //problem 1
            // declare variables
            int one, two, three;
            
            //get the numbers
            cout << "What is the first number?" << endl;
            cin >> one;
            cout << "What is the second number?" << endl;
            cin >> two;

            //figure which one is larger
            three = (one>two)? (three = one) : (three = two);

            //output the larger one
            cout << "The larger number is " << three << endl;}
            break;
        case (2):{ //problem 2
            //declare variables
            int num;

            //get input
            cout << "What number do you want to be converted into a Roman numeral?" << endl;
            cout << "Input a number between 1 and 10." << endl;
            cin >> num;

            //do the conversion
            switch (num) {
                case 1: cout << "The Roman numeral for 1 is I." << endl;
                        break;
                case 2: cout << "The Roman numeral for 2 is II." << endl;
                        break;
                case 3: cout << "The Roman numeral for 3 is III." << endl;
                        break;
                case 4: cout << "The Roman numeral for 4 is IV." << endl;
                        break;
                case 5: cout << "The Roman numeral for 5 is V." << endl;
                        break;
                case 6: cout << "The Roman numeral for 6 is VI." << endl;
                        break;
                case 7: cout << "The Roman numeral for 7 is VII." << endl;
                        break;
                case 8: cout << "The Roman numeral for 8 is VIII." << endl;
                        break;
                case 9: cout << "The Roman numeral for 9 is IX." << endl;
                        break;
                case 10: cout << "The Roman numeral for 10 is X." << endl;
                        break;
                default: cout << "Please select a number between 1 and 10." << endl;
            }
        }
            break;
        case (3):{ //problem 3
            //declare variables
            int day, month, year;

            //get the input 
            cout << "Enter the day" << endl;
            cin >> day;
            cout << "Enter the month" << endl;
            cin >> month;
            cout << "Enter the year" << endl;
            cin >> year;

            //figure out if the date is "magic"
            if (year == month * day) 
                cout << "It's a magical date. Congratulations." << endl;
            else 
                cout << "It's a normal, boring day. Have fun." << endl;}
            break;
        case (4):{ //problem 4
            //declare variables
            int length1, length2, width1, width2, area1, area2;

            //get the info
            cout << "What is the length of rectangle 1?" << endl;
            cin >> length1;
            cout << "What is the width of rectangle 1?" << endl;
            cin >> width1;
            cout << "What is the length of rectangle 2?" << endl;
            cin >> length2;
            cout << "What is the width of rectangle 2?" << endl;
            cin >> width2;

            //figure out the areas
            area1 = length1 * width1;
            area2 = length2 * width2;

            //figure out which one is bigger and tell the user    
            if (area1>area2)
                cout << "Rectangle 1 is larger." << endl;
            if (area1<area2)
                cout << "Rectangle 2 is larger." << endl;
            if (area1==area2)
                cout << "Both rectangles have the same area" << endl;}
            break;
        case (5):{ //problem 5
            //declare variables
            float weight, height, bmi;

            //get the input
            cout << "What is your weight? (Enter in pounds)" << endl;
            cin >> weight;
            cout << "What is your height? (Enter in inches)" << endl;
            cin >> height;

            //calculate bmi
            bmi = weight * 703 / pow(height,2);

            //determine is bmi is underweight, optimal, or overweight
            if (bmi < 18.5)
                cout << "You are underweight, your bmi is " << bmi << endl;
            if (bmi > 18.5 && bmi < 25)
                cout << "You are at an optimal weight, your bmi is " << bmi << endl;
            if (bmi > 25)
                cout << "You are overweight, your bmi is " << bmi << endl;}
            break;
        case (6):{ //problem 6
            //declare variables
            float weight, newtons;

            //get the input
            cout << "What is the weight? (Enter in kilograms)" << endl;
            cin >> weight;

            //calculate newtons
            newtons = weight * 9.8;

            //determine is weight is too light or too heavy or just right
            if (newtons < 10)
                cout << "The object is too light" << endl;
            if (newtons > 1000)
                cout << "The object is too heavy" << endl;
            if (newtons > 10 && newtons < 1000)
                cout << "The objects weights " << newtons << " newtons." << endl;}
            break;
        case (7):{ //problem 7
            //declare variables
            int seconds, minutes, hours, days;

            //get the input
            cout << "How many seconds?" << endl;
            cin >> seconds;

            //do the conversion
            minutes = seconds / 60;
            hours = seconds / 3600;
            days = seconds / 86400;

            if (seconds >= 60 && seconds < 3600)
                cout << "There are " << minutes << " minutes in " << seconds << " seconds" << endl;
            if (seconds >= 3600 && seconds < 86400)
                cout << "There are " << hours << " hours in " << seconds << " seconds" << endl;
            if (seconds >= 86400)
                cout << "There are " << days << " days in " << seconds << " seconds" << endl;}
            break;
        case (8):{ //problem 8
            //declare variables
        char one, two;

        //get the input
        cout << "What is the first color? Enter r for red, y for yellow, or b for blue" << endl;
        cin >> one;
        cout << "What is the second color? Enter r for red, y for yellow, or b for blue" << endl;
        cin >> two;

        //do the conversion
        switch (one) {
            case 'r': //if red .
                switch (two) {
                    case 'b':
                        cout << "Red and blue give purple." << endl;
                        break;
                    case 'y':
                        cout << "Red and yellow give orange." << endl;
                        break;
                    default: cout << "Error 1" << endl;
                        break;
                } break;
            case 'b':
                switch (two) {
                    case 'r':
                        cout << "Blue and red give purple." << endl;
                        break;
                    case 'y':
                        cout << "Blue and yellow give green." << endl;
                        break;
                    default: cout << "Error 2" << endl;
                } break;
            case 'y':
                switch (two) {
                    case 'r':
                        cout << "Yellow and red give orange." << endl;
                        break;
                    case 'b':
                        cout << "Yellow and blue give green." << endl;
                        break;
                    default: cout << "Error 3" << endl;
                } break;
            default: cout << "Error 4" << endl;
            }
        }
            break;
        case (9):{ //problem 9
            int penny, nickel, dime, quarter, total; //different coins for the game

            cout << "How many pennies?" << endl; // get the inputs for each coin
            cin >> penny;
            cout << "How many nickels?" << endl;
            cin >> nickel;
            cout << "How many dimes?" << endl;
            cin >> dime;
            cout << "How many quarters?" << endl;
            cin >> quarter;

            penny = penny*1; // do the math for the coin values
            nickel = nickel*5;
            dime = dime*10;
            quarter = quarter*25;
            total = penny+nickel+dime+quarter;

            if (total < 100) //figure out if they've won or not
                cout << "Too few, try again." << endl;
            if (total == 100)
                cout << "You win! Good job." << endl;
            if (total > 100)
                cout << "Too many, try again." << endl;}
            break;
        case (10):{ //problem 10
            int month, year; //variables for the problem
    
            cout << "What is the year?" << endl; // get the inputs
            cin >> year;
            cout << "What is the month? Enter as a number." << endl;
            cin >> month; 

            //figure it out

            if (month == 1)
                cout << "31 days." << endl;
            if (month == 2 && year%100!=0 && year%4 !=0) // not a leap year
                cout << "28 days." << endl;
            if (month == 2 && year%100==0 && year%400==0 || month ==2 && year%4==0)// leap year
                cout << "29 days." << endl;
            if (month == 3)
                cout << "31 days." << endl;
            if (month == 4)
                cout << "30 days." << endl;
            if (month == 5)
                cout << "30 days." << endl;
            if (month == 6)
                cout << "31 days." << endl;
            if (month == 7)
                cout << "31 days." << endl;
            if (month == 8)
                cout << "31 days." << endl;
            if (month == 9)
                cout << "30 days." << endl;
            if (month == 10)
                cout << "31 days." << endl;
            if (month == 11)
                cout << "30 days." << endl;
            if (month == 12)
                cout << "31 days." << endl;}
            break;
        default: //exit strategy
            cout << "Program will now exit." << endl;
        }
    //thats all folks
    return 0;
}

