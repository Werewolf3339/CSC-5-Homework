/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 30, 2016, 9:31 AM
 * Purpose: creating a menu to view problems 1-10, using a do loop
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() 

//execution begins here

{
    int key; // menu selection
    
    do {
        cout << "Enter a number, 1-10, in order to view that problem." << endl;
        cout << "Entering anything other than 1-10 will cause the menu to exit."
                << endl;
        cin >> key;

        switch (key) {
            case (1):{ //problem 1
                int count = 0; //how many times the program has counted
        int goal; //what number is the last one to be added
        int total; //the total value of the numbers

        //get the input
        cout << "What number should be added with all previous numbers? It must"
                " be a positive integer." << endl;
        cin >> goal;

        //if it's positive then proceed
        if (goal > 0) {
            do  (total += count, count ++);
            while (count <= goal);
            cout << "The sum of total of " << goal << " and the numbers less "
                    "than itself is " << total << endl;
        }
        if (goal <= 0)// if its not positive then try again
            cout << "Please enter a positive integer value." << endl;
            }break;
            case (2):{ //problem 2
                //declare variables
        int count = 0;

        //setup the display for the numbers
        while (count <= 127) {
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << (char) count << " ";
            count++;
            cout << endl;} 
            //have it display 16 characters before it goes to the next line
            }break;
            case (3):{ //problem 3
                //declare variables
        float oclvl = 0, change = 1.5; // ocean level, how much it changes per year
        int year = 0; //number of years

        //calculate the rise
        for (change = 1.5; year <= 25; year++) {
            oclvl+=change;
            cout << "The ocean level for year "<<year<<" is "<<oclvl<<" mm."
                    <<endl;}
            }break;
            case (4):{ //problem 4
                //declare variables
        float burnrte = 3.6, burned; 
        //number of calories burned per minute, numbers of total calories burned
        int mins = 0; //how many minutes on the treadmill its been

        //do the calculation and output the results for 5 min increments
        for (burnrte=3.6; mins<=30; mins++) {
            burned=burnrte*mins;
            mins+=4;
            cout<<"You will burn "<<burned<<" for "<<mins<<" minutes of work."
                    <<endl;}
            }break;
            case (5):{ //problem 5
                //declare variables
        float fee = 2500, inc = 1.04;
        //starting free is 2500, increases 4% per year
        int year = 1; // what year it is

        //calculate the increase for 6 years
        for (fee=2500; year<=6; year++) {
            fee=fee*inc;
            cout<<"The fee for year "<<year<<" is $"<<fee<<endl;
        }
            }break;
            case (6):{ //problem 6
                //declare variables
            int speed, distanc, donetim, hours, error=0;
            //speed of the vehicle, how far its gone, how long its traveled, 
            //and placeholder, and error message

            //get the inputs
            cout<<"What is the speed of the vehicle?" 
                    " Enter a positive whole number."<<endl;
            cin>>speed;
            cout<<"How long has it been traveling?"
                    " Enter a whole number no less than 1."<<endl;
            cin>>donetim;

            //validate the input
            if (speed<0){
                error++;
                cout<<"Enter a positive number next time."<<endl;
            }

            if (donetim<1){
                error++;
                cout<<"Enter a number 1 or greater next time."<<endl;
            }

            //calculate the answer
            if (error==0){
                for (hours=1;hours<=donetim;hours++) {
                    distanc=speed*hours;
                    cout<<"During hour "<<hours<<" you will have traveled a total "
                            "of "<<distanc<<" miles, assuming you entered miles "
                            "per hour."<<endl;}}
            }break;
            case (7):{ //problem 7
                //declare variables
        float today, total;//todays wages, total wages
        int error = 0, numday, count; //for input validation and counting days

        //get the input
        cout<<"How many days were worked? Enter a positive integer."<<endl;
        cin>>numday;

        //input validation
        if (numday<0){
            error++;
            cout<<"Enter a positive number next time"<<endl;
        }

        cout<<fixed<<showpoint<<setprecision(2);

        //do the calculations
        if (error==0){
            for (count=1;count<=numday;count++){
                today=0.01*pow(2, count);
                total=total+today;
                cout<<"Day "<<count<<"'s wages were $"<<today
                    <<". So far total wages total $"<<total<<"."<<endl;}}
            }break;
            case (8):{//problem 8
                //declare variables
    int floors=0, rpf=0, occrm=0, ttlroom=0, ttlocc=0, ttlunoc=0, count=0,
            error=0;
    //how many floors, room per floor, occupied rooms, total rooms in the hotel,
    //total occupied rooms in the hotel, total unoccupied rooms in the hotel
    //count, and input validation
    float perocc;
    //percentage of occupied rooms in the hotel
    
    //figure out how many floors the hotel has
    cout<<"How many floors does the hotel have?"<<endl;
    cin>>floors;
    
    //input validation
    if (floors<1){
        error++;
        cout<<"The hotel must have at least 1 floor."<<endl;
    }
        
    //start the floor-by-floor loop, skipping floor 13.
    if (error==0){
        for (count=1;count<=floors;count++){
            if (count!=13){   
                cout<<"How many rooms are on floor "<<count<<"?"<<endl;
                cin>>rpf;
                if (rpf<10){
                    error++;
                    cout<<"The hotel must have at least 10 rooms per floor."
                            <<endl; break;
                }
                if (error==0){
                    ttlroom=ttlroom+rpf;
                    cout<<"How many of the rooms are occupied?"<<endl;
                    cin>>occrm;
                    ttlocc=ttlocc+occrm;
                    ttlunoc=ttlroom-ttlocc;}}}}
    
        //give them the information
        if (error==0){
            perocc=100*(1.0f*ttlocc/ttlroom);
            cout<<"The hotel has "<<ttlroom<<" rooms."<<endl;
            cout<<"Of those rooms, "<<ttlocc<<" are occupied."<<endl;
            cout<<"Which means that "<<ttlunoc<<" rooms are unoccupied."<<endl;
            cout<<perocc<<"% of rooms in the hotel are occupied."<<endl;}
            }break;
            case (9):{ //problem 9
                //declare variables
        int years=0, ttlrain=0, rain=0, count1=0, ttlmont=0, error=0, count2=0;
        //total years, total rain, rain per month, count, total months, 
        float avgrain=0;
        //avg rain per month

        //get the input
        cout<<"How many years will data be collected for?"<<endl;
        cin>>years;

        //input validation
        if (years<1){
            error++;
            cout<<"You must collect data for at least 1 year."<<endl;
        }

        //calculate rainfall using loops
        if (error==0) {
            for (count1=1;count1<=years;count1++){ //year loop
                if (error==0){
                    for (count2=1;count2<=12;count2++){ // month loop
                        cout<<"For month "<<count2<<" how many inches of rainfall"
                                " were there?"<<endl;
                        cin>>rain;
                        if (rain<0){
                            error++;
                            cout<<"There must be at least 0 inches of rainfall per "
                                    "month."<<endl; break;
                        }
                        ttlrain=ttlrain+rain; // total rain
                        ttlmont=years*12; // total months 
                        avgrain=1.0f*ttlrain/ttlmont; //average rainfall
                    }
                }
            }
        }

        //output the results
        if (error==0){  
            cout<<"Data was collected for a total of "<<ttlmont<<" months."<<endl;
            cout<<"The total amount of rainfall was "<<ttlrain<<" inches."<<endl;
            cout<<"Average rainfall for those months was "<<avgrain<<" inches."
                    <<endl;}
            }break;
            case (10):{ //problem 10
                //declare variables
    float start=0; //starting population size
    float inc=0; //%increase in population
    int days=0; //how many days it will predict
    int count=0; //count
    
    //get the inputs
    while (start<2){ 
        cout<<"What is the starting population size? Min of 2."<<endl;
        cin>>start;
        if (start<2){
        cout<<"The starting population must be at least 2."<<endl;}}
    while (inc<=0){
        cout<<"What is the daily population increase? Enter as a positive %."
                <<endl;
        cin>>inc;
        if (inc<=0){
            cout<<"Please input a positive %."<<endl;}}
    while (days<=0){
        cout<<"How many days will be predicted? Enter as a positive integer."
                <<endl;
        cin>>days;
        if (days<=0){
            cout<<"Please enter a positive integer."<<endl;}}
    
    inc=inc*0.01; //convert to a decimal
    cout<<showpoint<<fixed<<setprecision(0);
    
    //map the inputs to the outputs
    for (count=1;count<=days;count++){
        start*=(1+inc);
        cout<<"On day "<<count<<" there are "<<start<<"0 organisms."<<endl;
    }
            }break;
            default: //exit strategy
                cout << "Program will now exit." << endl;
            }
        }
    while (key >= 1 && key <= 10);
    //thats all folks
    return 0;
}

