/* 
 * File:   main.cpp
 * Author: Brandon Fins
 * Created on March 30, 2016, 9:31 AM
 * Purpose: creating a menu to view problems 1-10, using functions
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

//function prototypes
void prob1();
float calculateRetail(float,float);
void prob2();
float getlength();
float getwidth();
float getarea (float, float);
void displaydata(float);
void prob3();
float getsales(string);
void findhighest(float, float, float, float);
void prob4();
int getaccidents(string);
void findlowest(int, int, int, int, int);
void prob5();
float fallingdistance(int);
void prob6();
float kineticenergy(int, int);
void prob7();
float celsius(float);
void prob8();
int cointoss (int);
void prob9();
float fvalue(int, float, int);
void prob10();
float futurevalue(int, float, int);

int main() 

//execution begins here

{
    int key; // menu selection
    
    do {
        cout << "\nEnter a number, 1-10, in order to view that problem." << endl;
        cout << "Entering anything other than 1-10 will cause the menu to exit."
                << endl;
        cin >> key;

        switch (key) {
            case (1):{ //problem 1
                prob1();
            }break;
            case (2):{ //problem 2
                prob2();
            }break;
            case (3):{ //problem 3
                prob3();
            }break;
            case (4):{ //problem 4
                prob4();
            }break;
            case (5):{ //problem 5
                prob5();
            }break;
            case (6):{ //problem 6
                prob6();
            }break;
            case (7):{ //problem 7
                prob7();
            }break;
            case (8):{//problem 8
                prob8();
            }break;
            case (9):{ //problem 9
                prob9();
            }break;
            case (10):{ //problem 10
                prob10();
            }break;
            default: //exit strategy
                cout << "Program will now exit." << endl;
            }
        }
    while (key >= 1 && key <= 10);
    //thats all folks
    return 0;
}

void prob1(){
    //declare variables
    float wholesl, mrkup;
    //wholesale price and markup percentage
    cout<<"What is the wholesale cost of the item?"<<endl;
    cin>>wholesl;
    cout<<"What is the markup %?"<<endl;
    cin>>mrkup;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The price of the item will be $"<<calculateRetail(wholesl, mrkup);
}
float calculateRetail(float wholesl,float mrkup){
    return (wholesl+wholesl*(mrkup/100));
    }

void prob2(){
    //declare variables
    float length, width, area;
    length=getlength();
    width=getwidth();
    area=getarea(length, width);
    displaydata(area);
}
float getlength(){
    float length;
    cout<<"What is the length of the rectangle?"<<endl;
    cin>>length;
    return length;           
}
float getwidth(){
    float width;
    cout<<"What is the width of the rectangle?"<<endl;
    cin>>width;
    return width;           
}
float getarea (float l, float w){
    return (l*w);
}
void displaydata(float a){
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The area of the rectangle is "<<a<<endl;
}

void prob3(){
    //declare variables
    float nwsales, swsales, nesales, sesales;
    string nw="Northwest", sw="Southwest", ne="Northeast", se="Southeast";
    nwsales=getsales(nw);
    swsales=getsales(sw);
    nesales=getsales(ne);
    sesales=getsales(se);
    findhighest(nwsales, swsales, nesales, sesales);
}
float getsales(string name){
    float sales;
    do{
    cout<<"What was the sales total for the "<<name<<" division?"<<endl;
    cin>>sales;}
    while (sales<0);
    return sales;
}
void findhighest(float num1, float num2, float num3, float num4){
    if (num1>num2&&num1>num3&&num1>num4){
        cout<<"Northwest division won with $"<<num1<<" in sales.";}
    if (num2>num1&&num2>num3&&num2>num4){
        cout<<"Southwest division won with $"<<num2<<" in sales.";}
    if (num3>num2&&num3>num1&&num1>num4){
        cout<<"Northeast division won with $"<<num3<<" in sales.";}
    if (num4>num1&&num4>num2&&num4>num3){
        cout<<"Southeast division won with $"<<num4<<" in sales.";}
    }

void prob4(){
    //declare variables
    int north, east, west, south, central;
    string North="North", East="East", West="West", South="South", 
            Central="Central";
    north=getaccidents(North);
    east=getaccidents(East);
    west=getaccidents(West);
    south=getaccidents(South);
    central=getaccidents(Central);
    findlowest(north, east, west, south, central);
}
int getaccidents(string name){
    int accident;
    do{
    cout<<"What was the total number of accidents for the "<<name<<" are of "
            "the city?"<<endl;
    cin>>accident;}
    while (accident<0);
    return accident;
}
void findlowest(int num1, int num2, int num3, int num4, int num5){
    if (num1<num2&&num1<num3&&num1<num4&&num1<num5){
        cout<<"The north section of the city had the fewest accidents with "
                "only "<<num1<<endl;}
    if (num2<num1&&num2<num3&&num2<num4&&num2<num5){
        cout<<"The east section of the city had the fewest accidents with "
                "only "<<num2<<endl;}
    if (num3<num2&&num3<num1&&num1<num4&&num3<num5){
        cout<<"The west section of the city had the fewest accidents with "
                "only "<<num3<<endl;}
    if (num4<num1&&num4<num2&&num4<num3&&num4<num5){
        cout<<"The south section of the city had the fewest accidents with "
                "only "<<num4<<endl;}
    if (num5<num1&&num5<num2&&num5<num3&&num5<num4){
        cout<<"The central section of the city had the fewest accidents with "
                "only "<<num5<<endl;}
    }

void prob5(){
    //declare variables
    float distance;//distances in meters
    int time;//the number of seconds object has been falling
    for (time=1;time<=10;time++){
        cout<<"The object has fallen "<<fallingdistance(time)<<" meters."<<endl;
    }}
float fallingdistance(int time){
  return (0.5f*9.8*time*time);  
}

void prob6(){
    //declare variables
    int mass;//mass in kilos
    int vlocity;//velocity in meters per second
    cout<<"What is the objects mass?"<<endl;
    cin>>mass;
    cout<<"What is the objects velocity?"<<endl;
    cin>>vlocity;
    cout<<"The objects kinetic energy is "<<kineticenergy(mass, vlocity)<<endl;
}
float kineticenergy(int mass, int vlocity){
  return (0.5f*mass*vlocity*vlocity);  
}

void prob7(){
    //declare variables
    int fdegree;//degrees in fahrenheit
    for (fdegree=0;fdegree<=20;fdegree++){
        cout<<fdegree<<" degrees in fahrenheit is "<<celsius(fdegree)
                <<" degrees in celsius"<<endl;
    }  
}
float celsius(float fdegree){
    fdegree=fdegree-32;
    return (5.0f/9*fdegree);
}

void prob8(){
    //declare variables
    int heads, times;
    srand(static_cast<unsigned int>(time(0)));
    
    cout<<"How many coin tosses should be simulated?"<<endl;
    cin>>times;
    
    heads=cointoss(times);
    
    cout<<"Number of heads: "<<heads<<endl;
    cout<<"Number of tails: "<<(times-heads)<<endl;
    cout<<"Total tosses: "<<times<<endl;
}
int cointoss(int times){
    int heads;
    for (int count=0;count<times;count++){
        if ((rand()%2+1)==1){
            heads++;
        }
    }
    return heads;
}

void prob9(){
    //declare variables
    int present, future, years;
    float rate;
    cout<<"What is the desired future value?"<<endl;
    cin>>future;
    cout<<"What is the interest rate? Enter as a decimal."<<endl;
    cin>>rate;
    cout<<"How many years will it get to accumulate?"<<endl;
    cin>>years;
    
    present=fvalue(future, rate, years);
    cout<<"The amount you need to have at present is $"<<present<<endl;
}
float fvalue(int future, float rate, int years){
    float present;
    present=(future/(pow((1+rate),years)));
    return present;
}

void prob10(){
    //declare variables
    int present, future, months;
    float rate;
    cout<<"What is the present value?"<<endl;
    cin>>present;
    cout<<"What is the interest rate? Enter as a decimal."<<endl;
    cin>>rate;
    cout<<"How many months will it get to accumulate?"<<endl;
    cin>>months;
    
    future=futurevalue(present, rate, months);
    cout<<"The amount you will have in the future is $"<<future<<endl;
}
float futurevalue(int present, float rate, int months){
    float future;
    future=(present*(pow((1+rate),months)));
    return future;
}